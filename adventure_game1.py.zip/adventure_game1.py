import time

import random


villian = ["gorgon", "dragon", "monster", "troll"]
enemy = random.choice(villian)


def print_pause(message_to_print):
    print(message_to_print)
    time.sleep(1)


def valid_input(prompt, option1, option2):
    while True:
        response = input(prompt).lower()
        if option1 == response:
            break
        elif option2 == response:
            break
        else:
            print_pause("Sorry, this is invalid. Try again")
    return response


def intro():
    print_pause("You find yourself standing in an open field")
    print_pause("filled with grass and yellow wildflowers.\n")
    print_pause(f"Rumor has it that a '{enemy}' is somewhere around here,"
                "and has been terrifying the nearby village.\n")
    print_pause("In front of you is a house.\n")
    print_pause("To your right is a dark cave.\n")
    print_pause("In your hand you hold you fr trusty (but not effective)"
                "dagger.")


def choice():
    response = valid_input("Time to Decide! "
                           "Would You like to fight or run?\n",
                           "fight", "run")
    if "fight" in response:
        print_pause("You do Your best!")
        print_pause(f"but your dagger is no match for the '{enemy}'.\n")
        print_pause("You have been defeated! ")
        print_pause("Game Over!")
        play_again()
    elif "run" in response:
        print_pause("You run back into the field. ")
        print_pause("Luckily,you dont seem to have been follwed")
        response = valid_input("Would you like to try again? 'yes' or 'no'.\n",
                               "yes", "no")
        if "yes" == response:
            print_pause("Lets GO!!")
            fight()
        elif "no" == response:
            print_pause("Thank you for playing! See You.")
            exit(0)


def knock():
    print_pause("You approach the door of the house.\n")
    print_pause("You are about to knock when the door opens\n")
    print_pause(f"Out steps and '{enemy}'.\n")
    print_pause(f"Eep! This is a '{enemy}' house!\n")
    print_pause(f"The '{enemy}' attacks you!\n ")
    print_pause("For this, with only having a tiny dagger. \n")
    choice()


def cave():
    print_pause("You peer cautiously into the cave.\n")
    print_pause("It turns out to be only a very small cave. ")
    print_pause("Your eye catches a glint of metal behind a rock.\n")
    print_pause("You have found the magical Sword of Ogoroth!\n")
    print_pause("You discard your silly old dagger")
    print_pause("and take the sword with you.\n")
    print_pause("You walk back out of the field.")
    which_way()


def fight():
    print_pause(f"As the '{enemy}' moves to attack, ")
    print_pause("you unsheath your new sword.")
    print_pause("The sword of ogoroth shines brightly in your hand ")
    print_pause("As you brace yourself for the attack.")
    print_pause(f"But the '{enemy}' takes one look at your shiny new toy")
    print_pause("and runs away!")
    print_pause(f"You have rid the town of the '{enemy}'.")
    print_pause("You are victourious! ")
    play_again()


def play_again():
    response = valid_input("Would you like to play again? "
                           "Enter 'yes' or 'no'.\n",
                           "yes", "no")
    if "yes" == response:
        print_pause("Excellent! Let me restart the Game...")
        global enemy
        enemy = random.choice(villian)
        start_game()
    elif "no" == response:
        print_pause("Thank You for Playing! See you soon")
        exit(0)


def which_way():
    while True:
        response = valid_input("Enter 1 to knock on the door of the house "
                               "Enter 2 to peer into the cave.\n",
                               "1", "2")
        if response == "1":
            knock()
        elif response == "2":
            cave()
        else:
            print_pause("Invalid input, try again.")


def start_game():
    intro()
    which_way()
    choice()
    play_again()


start_game()
